package edu.baylor.hci.Calibration;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Vector;

import com.leapmotion.leap.Controller;

import edu.baylor.hci.Calibration.CalibrationView.CalibrationButtons;
import edu.baylor.hci.LeapOMatic.GuiListener;
import edu.baylor.hci.LeapOMatic.PositionLog;
import edu.baylor.hci.LeapOMatic.PositionLog.LogStatus;
import edu.baylor.hci.LeapOMatic.TouchPoints;
import net.sf.javaml.clustering.Clusterer;
import net.sf.javaml.clustering.DensityBasedSpatialClustering;


import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.DefaultDataset;
import net.sf.javaml.core.DenseInstance;
import net.sf.javaml.core.Instance;

import javax.swing.JFrame;
import javax.swing.Timer;

import org.apache.log4j.Logger;

public class Calibration extends JFrame implements ActionListener {
	private static final int SCREEN_HEIGHT = 1600;

	private static final int SCREEN_WIDTH = 2560;

	/** class constants **/
	private static final long serialVersionUID = 1L;
	
	private static final int INITIAL_DELAY = 5000;
	private static final int TIMER_INTERVAL = 2500;
	private static final int WINDOW_HEIGHT = 500;
	private static final int WINDOW_WIDTH = 500;
 	 // private static final int NUM_DIMENSIONS = 2; // not used

	private Controller controller= null;
	 // private com.leapmotion.leap.Vector data= null; // not used
	private Timer timer=null;
	// private ArrayList<Dataset> datasets= null; // not used
	private Dataset topRight= null;
	private Dataset topRightNormal= null;
	private Dataset topLeft = null;
	private Dataset topLeftNormal = null;
	private Dataset botLeft = null;
	private Dataset botLeftNormal = null;
	private Dataset botRight = null;
	private Dataset botRightNormal = null;
	private CalibrationView view = null;
	private PositionLog positionLog = null;
	private GuiListener guiListener = null;
	
	private CalibrationLogger calibrationLog;
	
    private static final Logger logger = Logger.getLogger(Calibration.class);

    
	private int timerCount=0;
	public Calibration()
	{
		this.setTitle("Calibration Exercise");
	    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    this.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	    this.setVisible(true);

	    calibrationLog = new CalibrationLogger("calibrationLog"+TouchPoints.getNameToAppend());
	    positionLog = new PositionLog("log1");
        guiListener = new GuiListener(positionLog);
        
	    view = new CalibrationView();
	    add(view);
	    
	    controller 	= new Controller();
	    controller.addListener(guiListener);
	    timer= new Timer(TIMER_INTERVAL, this);
	    timer.setInitialDelay(INITIAL_DELAY);
	    timer.start();
	    
	    
	}
	
	public void actionPerformed(ActionEvent e)
	{
		timerCount++;
		getCalibrationDatasets();
	}
	
	/*
	 * Every 2.5 seconds(specified by TIMER_INTERVAL) this function is called. On odd calls we toggle the visibility indicating the user to move their hand to this position.
	 * On even calls we start the collection of points, so the user has 2.5 seconds to react and place their hand to the specified position.
	 * At the start of the next odd call we extract the points into a dataset for the clustering algorithm, and toggle the next visibility.
	 * 
	 */
	public void getCalibrationDatasets()
	{    
		if(timerCount==1)
		{
			view.toggleVisibility(CalibrationButtons.TOP_RIGHT);	
		}
		else if(timerCount == 2 )
		{
			positionLog.clearArrays();
			positionLog.setLogStatus(LogStatus.START);		
		}
		else if(timerCount == 3)
		{
			//extract Points
			positionLog.setLogStatus(LogStatus.STOP);
			topRight= collectPoints();
			topRightNormal= collectPalmNormal();
			view.toggleVisibility(CalibrationButtons.TOP_LEFT);
		}
		else if(timerCount == 4)
		{
			positionLog.clearArrays();
			positionLog.setLogStatus(LogStatus.START);
		}
		else if(timerCount ==5)
		{	
			//extract points
			positionLog.setLogStatus(LogStatus.STOP);
			topLeft= collectPoints();
			topLeftNormal=collectPalmNormal();
			view.toggleVisibility(CalibrationButtons.BOT_LEFT);
		}
		else if(timerCount == 6)
		{
			//toggle Point collection
			//
			positionLog.clearArrays();
			positionLog.setLogStatus(LogStatus.START);
		}
		else if(timerCount ==7)
		{
			//extract Points
			positionLog.setLogStatus(LogStatus.STOP);
			botLeft = collectPoints();
			botLeftNormal = collectPalmNormal();
			view.toggleVisibility(CalibrationButtons.BOT_RIGHT);
		}
		else if(timerCount == 8)
		{
			//togglePoint collection
			positionLog.clearArrays();
			positionLog.setLogStatus(LogStatus.START);
			
		}
		else
		{
			positionLog.setLogStatus(LogStatus.STOP);
			botRight = collectPoints();
			botRightNormal = collectPalmNormal();
			timer.stop();
			view.toggleVisibility(CalibrationButtons.DISABLE);
			generateClustersAndTransformationMatrix();
		}
	}
	/**
	 * Goes through the positionLog that has been filled by each calibration point and builds the data set for the clustering algorithm.
	 * @return
	 */
	public Dataset collectPoints()
	{
		Dataset handCoordinates=new DefaultDataset();
		Instance instance = null;
		double point[]; 
		System.out.println(positionLog.getX().size());
		for(int i=0;i<positionLog.getX().size();i++) 
		{
			//x,y,z
			point= new double[3]; 
			point[0]=positionLog.getX().get(i);
			point[1]=positionLog.getY().get(i);
			point[2]=positionLog.getZ().get(i);

			instance = new DenseInstance(point);
			handCoordinates.add(instance);
			
		}
		return handCoordinates;
	}
	/**
	 * Obtains newly populated positionLog palmNormal points after the 2.5 second calibration point and stores for later clustering in order to obtain an "expected" palm normal position for the calibration point.
	 * @return
	 */
	public Dataset collectPalmNormal()
	{
		Dataset palmNormal=new DefaultDataset();
		Instance instance = null;
		double point[]; 
		System.out.println(positionLog.getX().size());
		for(int i=0;i<positionLog.getPalmNormalX().size();i++) 
		{
			//x,y,z
			point= new double[3]; 
			point[0]=positionLog.getPalmNormalX().get(i);
			point[1]=positionLog.getPalmNormalY().get(i);
			point[2]=positionLog.getPalmNormalZ().get(i);

			instance = new DenseInstance(point);
			palmNormal.add(instance);
		}
		return palmNormal;
	}
	/**
	 * First gets the cluster of points for each source coordinate(topRight, topLeft, botLeft, botRight).
	 * Then obtains the actual boundary we will be using from each cluster, and finally builds the transform matrix 
	 */
	public void generateClustersAndTransformationMatrix()
	{
		System.out.println("Generating Top Left Clusters");
		Dataset topLeftCluster = getMaxCluster(topLeft);
		Dataset topLeftNormalCluster = getMaxCluster(topLeftNormal);
		//Dataset topLeftNormal = getMaxCluster(topLeft);
		System.out.println("Generating Top Right Clusters");
		Dataset topRightCluster = getMaxCluster(topRight);
		Dataset topRightNormalCluster = getMaxCluster(topRightNormal);
		System.out.println("Generating Bottom Left Clusters");
		Dataset botLeftCluster = getMaxCluster(botLeft);
		Dataset botLeftNormalCluster = getMaxCluster(botLeftNormal);
		System.out.println("Generating Bottom Right Clusters");
		Dataset botRightCluster = getMaxCluster(botRight);
		Dataset botRightNormalCluster = getMaxCluster(botRightNormal);
		System.out.println("Obtained Max Clusters");
		/*
		 * Feed collectedPoints and clusters to the calibrationLog
		 */
		calibrationLog.loadDatasetToArrayLists(topRight, calibrationLog.topRight.CollectedX, calibrationLog.topRight.CollectedY, calibrationLog.topRight.CollectedZ);
		calibrationLog.loadDatasetToArrayLists(topLeft, calibrationLog.topLeft.CollectedX, calibrationLog.topLeft.CollectedY, calibrationLog.topLeft.CollectedZ);
		calibrationLog.loadDatasetToArrayLists(botLeft, calibrationLog.botLeft.CollectedX, calibrationLog.botLeft.CollectedY, calibrationLog.botLeft.CollectedZ);
		calibrationLog.loadDatasetToArrayLists(botRight, calibrationLog.botRight.CollectedX, calibrationLog.botRight.CollectedY, calibrationLog.botRight.CollectedZ);
		
		calibrationLog.loadDatasetToArrayLists(topRightCluster, calibrationLog.topRight.ClusterX, calibrationLog.topRight.ClusterY, calibrationLog.topRight.ClusterZ);
		calibrationLog.loadDatasetToArrayLists(topLeftCluster, calibrationLog.topLeft.ClusterX, calibrationLog.topLeft.ClusterY, calibrationLog.topLeft.ClusterZ);
		calibrationLog.loadDatasetToArrayLists(botLeftCluster, calibrationLog.botLeft.ClusterX, calibrationLog.botLeft.ClusterY, calibrationLog.botLeft.ClusterZ);
		calibrationLog.loadDatasetToArrayLists(botRightCluster, calibrationLog.botRight.ClusterX, calibrationLog.botRight.ClusterY, calibrationLog.botRight.ClusterZ);
		
		calibrationLog.loadDatasetToArrayLists(topRightNormal, calibrationLog.topRight.CollectedNormalX, calibrationLog.topRight.CollectedNormalY, calibrationLog.topRight.CollectedNormalZ);
		calibrationLog.loadDatasetToArrayLists(topLeftNormal, calibrationLog.topLeft.CollectedNormalX, calibrationLog.topLeft.CollectedNormalY, calibrationLog.topLeft.CollectedNormalZ);
		calibrationLog.loadDatasetToArrayLists(botLeftNormal, calibrationLog.botLeft.CollectedNormalX, calibrationLog.botLeft.CollectedNormalY, calibrationLog.botLeft.CollectedNormalZ);
		calibrationLog.loadDatasetToArrayLists(botRightNormal, calibrationLog.botRight.CollectedNormalX, calibrationLog.botRight.CollectedNormalY, calibrationLog.botRight.CollectedNormalZ);
		
		calibrationLog.loadDatasetToArrayLists(topRightNormalCluster, calibrationLog.topRight.ClusterNormalX, calibrationLog.topRight.ClusterNormalY, calibrationLog.topRight.ClusterNormalZ);
		calibrationLog.loadDatasetToArrayLists(topLeftNormalCluster, calibrationLog.topLeft.ClusterNormalX, calibrationLog.topLeft.ClusterNormalY, calibrationLog.topLeft.ClusterNormalZ);
		calibrationLog.loadDatasetToArrayLists(botLeftNormalCluster, calibrationLog.botLeft.ClusterNormalX, calibrationLog.botLeft.ClusterNormalY, calibrationLog.botLeft.ClusterNormalZ);
		calibrationLog.loadDatasetToArrayLists(botRightNormalCluster, calibrationLog.botRight.ClusterNormalX, calibrationLog.botRight.ClusterNormalY, calibrationLog.botRight.ClusterNormalZ);
		
		//we now have all maxClusters, now to approximate midpoints
		Vector<Double> topRightMidPt = getBounds(topRightCluster, "topRight");
		Vector<Double> topRightNormal = getBounds(topRightNormalCluster, "palmNormal");
		Vector<Double> topLeftMidPt = getBounds(topLeftCluster, "topLeft");
		Vector<Double> topLeftNormal = getBounds(topLeftNormalCluster, "palmNormal");
		Vector<Double> botLeftMidPt = getBounds(botLeftCluster, "botLeft");
		Vector<Double> botLeftNormal = getBounds(botLeftNormalCluster, "palmNormal");
		Vector<Double> botRightMidPt = getBounds(botRightCluster, "botRight");
		Vector<Double> botRightNormal = getBounds(botRightNormalCluster, "palmNormal");
		
		calibrationLog.loadMidPts(calibrationLog.topRight, "Point", topRightMidPt.get(0), topRightMidPt.get(1), topRightMidPt.get(2));
		calibrationLog.loadMidPts(calibrationLog.topLeft, "Point", topLeftMidPt.get(0), topLeftMidPt.get(1), topLeftMidPt.get(2));
		calibrationLog.loadMidPts(calibrationLog.botLeft, "Point", botLeftMidPt.get(0), botLeftMidPt.get(1), botLeftMidPt.get(2));
		calibrationLog.loadMidPts(calibrationLog.botRight, "Point", botRightMidPt.get(0), botRightMidPt.get(1), botRightMidPt.get(2));
		
		calibrationLog.loadMidPts(calibrationLog.topRight, "NormalPoint", topRightNormal.get(0), topRightNormal.get(1), topRightNormal.get(2));
		calibrationLog.loadMidPts(calibrationLog.topLeft, "NormalPoint", topLeftNormal.get(0), topLeftNormal.get(1), topLeftNormal.get(2));
		calibrationLog.loadMidPts(calibrationLog.botLeft, "NormalPoint", botLeftNormal.get(0), botLeftNormal.get(1), botLeftNormal.get(2));
		calibrationLog.loadMidPts(calibrationLog.botRight, "NormalPoint", botRightNormal.get(0), botRightNormal.get(1), botRightNormal.get(2));
		
		System.out.println("NORMALS:");
		System.out.println(topRightNormal);
		System.out.println(topLeftNormal);
		System.out.println(botLeftNormal);
		System.out.println(botRightNormal);
		// print to stdout
		System.out.println("Top Right " + topRightMidPt.toString());
		System.out.println("Top Left  " + topLeftMidPt.toString());
		System.out.println("Bot Left  " + botLeftMidPt.toString());
		System.out.println("Bot Right " + botRightMidPt.toString());
		
		logger.trace("Cluster Members, Top right: " + topRightCluster.toString());		
		logger.debug("Top Right " + topRightMidPt.toString());
		logger.trace("Cluster Members, Top left: " + topLeftCluster.toString());
		logger.debug("Top Left  " + topLeftMidPt.toString());
		logger.trace("Cluster Members, Bottom left: " + botLeftCluster.toString());
		logger.debug("Top Right " + botLeftMidPt.toString());
		logger.trace("Cluster Members, Bottom right: " + botRightCluster.toString());
		logger.debug("Bot Right " + botRightMidPt.toString());
		logger.debug("Top Right Normal"+topRightNormal);
		logger.debug("Top Left Normal"+topLeftNormal);
		logger.debug("Bot Left Normal"+botLeftNormal);
		logger.debug("Bot Right Normal"+botRightNormal);
		
		//now we have the source points
		buildTransformMatrix(topLeftMidPt, topRightMidPt, botLeftMidPt, botRightMidPt, topLeftNormal, topRightNormal, botLeftNormal, botRightNormal);	
	}
	/**
	 * Builds transform Matrix, and sets TouchPoints.transform to this matrix for computation later
	 * @param topLeftMidPt
	 * @param topRightMidPt
	 * @param botLeftMidPt
	 * @param botRightMidPt
	 */
	private void buildTransformMatrix(Vector<Double> topLeftMidPt,
												Vector<Double> topRightMidPt, 
												Vector<Double> botLeftMidPt,
												Vector<Double> botRightMidPt, 
												Vector<Double> topLeftNormal, 
												Vector<Double> topRightNormal,
												Vector<Double> botLeftNormal,
												Vector<Double> botRightNormal) {
		
		// represents the hand area
		double S1[][]= new double[][] {
				{topRightMidPt.get(0), topRightMidPt.get(1), topRightMidPt.get(2) },
				{topLeftMidPt.get(0) , topLeftMidPt.get(1) , topLeftMidPt.get(2)  },
				{botLeftMidPt.get(0) , botLeftMidPt.get(1) , botLeftMidPt.get(2)  },
				{botRightMidPt.get(0), botRightMidPt.get(1), botRightMidPt.get(2) }
			};
		//represents screen coordinates
		double screenDest[][]= new double[][]{
				{SCREEN_WIDTH, 0, 0}, //topRight
				{0, 0, 0}, //topLeft
				{0, SCREEN_HEIGHT, 0}, //botLeft
				{SCREEN_WIDTH, SCREEN_HEIGHT, 0} //botRight
		};
		double palmDest[][] = new double[][] {
				{topRightNormal.get(0), topRightNormal.get(1), topRightNormal.get(2) },
				{topLeftNormal.get(0) , topLeftNormal.get(1) , topLeftNormal.get(2)  },
				{botLeftNormal.get(0) , botLeftNormal.get(1) , botLeftNormal.get(2)  },
				{botRightNormal.get(0), botRightNormal.get(1), botRightNormal.get(2) }
		};
		logger.debug("Source		: " + Arrays.deepToString(S1));
		logger.debug("Destination 	: " + Arrays.deepToString(screenDest));
		
		try {
			TouchPoints.clearTransformMatrices();
			TouchPoints.getCoordinateTransformer().setInputMatrix(S1);
			TouchPoints.getPalmNormalTransformer().setInputMatrix(S1);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		
		TouchPoints.getCoordinateTransformer().setOutputMatrix(screenDest);
		TouchPoints.getPalmNormalTransformer().setOutputMatrix(palmDest);
		try {
			calibrationLog.calcZTransform=TouchPoints.getPalmNormalTransformer().getTransformationMatrix();
			calibrationLog.transformMatrix=TouchPoints.getCoordinateTransformer().getTransformationMatrix();
			calibrationLog.writeLog();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	/**
	 * Returns the particular bound for each cluster so that the point is most reachable e.g. minY maxX for topLeft.
	 * @param data
	 * @param cluster
	 * @return
	 */
	private Vector<Double> getBounds(Dataset data, String cluster)
	{
		Vector<Double> point3D= new Vector<Double>(); //will contain [0]=>x, [1]=>y, [2]=>z
		Double maxX=Double.NEGATIVE_INFINITY; 
		Double minX=Double.POSITIVE_INFINITY; 
		Double maxY=Double.NEGATIVE_INFINITY; 
		Double minY=Double.POSITIVE_INFINITY; 
		Double maxZ=Double.NEGATIVE_INFINITY; 
		Double minZ=Double.POSITIVE_INFINITY;
		
		Double X, Y, Z;
		for(Instance instance : data) //calculate running max and mins for each variable independently
		{
			X = instance.get(0);
			Y = instance.get(1);
			Z = instance.get(2);
			
			if(maxX<X){
				maxX=X;
			}
			if(minX>X)
			{
				minX=X;
			}
			if(maxY<Y)
			{
				maxY=Y;
			}
			if(minY>Y)
			{
				minY=Y;
			}
			if(maxZ<Z)
			{
				maxZ=Z;
			}
			if(minZ>Z)
			{
				minZ=Z;
			}
		}
		if(cluster=="topRight")
		{
			point3D.add(minX);
			point3D.add(minY);
		}
		else if(cluster=="topLeft")
		{
			point3D.add(maxX);
			point3D.add(minY);
		}
		else if(cluster=="botLeft")
		{
			point3D.add(maxX);
			point3D.add(maxY);
		}
		else if(cluster =="botRight")
		{
			point3D.add(minX);
			point3D.add(maxY);
		}
		else if(cluster =="palmNormal")
		{
			point3D.add((maxX+minX)/2);
			point3D.add((maxY+minY)/2);
		}
		point3D.add((maxZ+minZ)/2);
		return point3D;
	}
	
	
	/**
	 * 
	 * @param data
	 * @return
	 */
	private Dataset getMaxCluster(Dataset data)
	{
		System.out.println("ENTERED MAX CLUSter");
		Dataset[] clusters;
		Dataset maxCluster=null;
		int clusterSize=0;
		Clusterer dbScan= new DensityBasedSpatialClustering(10, 100);
		
		clusters = dbScan.cluster(data); 
		System.out.println(clusters.length);
		for(Dataset dataset : clusters)
		{
			System.out.println("LOOPING");
			if(dataset.size()>clusterSize)
			{
				maxCluster=dataset;
				clusterSize=maxCluster.size();
			}
		}
		return maxCluster;
		
	}
	
}

package edu.baylor.hci.Calibration;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.Instance;

import org.ejml.data.DenseMatrix64F;

import edu.baylor.hci.LeapOMatic.Settings;

/**
 * This class logs the following data in the calibration:
 * Points collected for each corner,
 * Points found to be in the cluster for each corner
 * Final points chosen to be the boundary for each corner,
 * The palm Normal collected for each corner
 * The palm Normal found to be in the cluster for each corner
 * Final palm normals for each corner
 * Transform Matrix
 * palmNormal Matrix
 * @author guinness
 *
 */
public class CalibrationLogger {
	class Corner
	{
		public ArrayList<Double> CollectedX = new ArrayList<Double>();
		public ArrayList<Double> CollectedY = new ArrayList<Double>();
		public ArrayList<Double> CollectedZ = new ArrayList<Double>();
		
		public ArrayList<Double> ClusterX = new ArrayList<Double>();
		public ArrayList<Double> ClusterY = new ArrayList<Double>();
		public ArrayList<Double> ClusterZ = new ArrayList<Double>();
		
		public Double PointX;
		public Double PointY;
		public Double PointZ;
		
		public ArrayList<Double> CollectedNormalX = new ArrayList<Double>();
		public ArrayList<Double> CollectedNormalY = new ArrayList<Double>();
		public ArrayList<Double> CollectedNormalZ = new ArrayList<Double>();
		
		public ArrayList<Double> ClusterNormalX = new ArrayList<Double>();
		public ArrayList<Double> ClusterNormalY = new ArrayList<Double>();
		public ArrayList<Double> ClusterNormalZ = new ArrayList<Double>();
		
		public Double NormalPointX;
		public Double NormalPointY;
		public Double NormalPointZ;
	}
	/*made public to be able to be accessed outside the class, no getters and setters because one would have to be made for each field in Corner
	 * 
	 */
	public Corner topRight = new Corner();
	public Corner topLeft = new Corner();
	public Corner botLeft = new Corner();
	public Corner botRight = new Corner();
	
	public DenseMatrix64F transformMatrix;
	public DenseMatrix64F calcZTransform;
	
	
	private BufferedWriter outfile;
	private String logfile;
	
	
	
	public CalibrationLogger(String logfilePrefix) {	
			// if the directory does not exist, create it or die trying. 
			File dir = new File(Settings.LOGFILE_DIR); 
			if (!dir.exists()) {
				//logger.debug("creating directory: " + dir);
				if(dir.mkdir()) {    
					//logger.debug("dir created");  
				} else {
					//logger.fatal("Could not create directory");
					System.exit(1);
				}
			} else {
				//logger.debug("Dir exists");
			}
			
			Date dateNow = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat(Settings.DATE_FORMAT);
	        StringBuilder strDatenow = new StringBuilder(dateFormat.format(dateNow));
	        
			this.logfile = dir + File.separator + logfilePrefix + "_" + strDatenow + ".m";
	}
	
	
	private void write(String value) {

		try {
			this.outfile.append(value);
		} catch (IOException e) {
			//logger.fatal(e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
	}
	private void writePoints(String varname, double x, double y, double z)
	{
		writeScalar(varname+"X", x);
		writeScalar(varname+"Y", y);
		writeScalar(varname+"Z", z);
	}
	
	private void writeDoubleVars(String varname, ArrayList<Double> arraylist) {
		// write this one var
		write(varname + " = [");
		
		Iterator<Double> iterator = arraylist.iterator();
		while(iterator.hasNext()) {
			write(iterator.next().toString());
			if(iterator.hasNext()) {
				write(",");
			}
		}
		write("]");
		write("\n");
		// flush per var
		try {
			this.outfile.flush();
		} catch (IOException e) {
			//logger.fatal(e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	private void writeScalar(String varname, double value)
	{
		write(varname+" = "+value+"\n");
	}
	
	public void loadMidPts(Corner corner, String label, Double x, Double y, Double z)
	{
		if(label=="Point")
		{
			corner.PointX=x;
			corner.PointY=y;
			corner.PointZ=z;
		}
		else if(label=="NormalPoint")
		{
			corner.NormalPointX=x;
			corner.NormalPointY=y;
			corner.NormalPointZ=z;
		}
	}
	
	public void loadDatasetToArrayLists(Dataset data, ArrayList<Double> x, ArrayList<Double> y, ArrayList<Double> z)
	{
		for(Instance instance : data) 
		{
			x.add(instance.get(0));
			y.add(instance.get(1));
			z.add(instance.get(2));
		}
	}
	
	public void writeCorner(Corner corner, String label)
	{
		this.writeDoubleVars(label+"CollectedX", corner.CollectedX);
		this.writeDoubleVars(label+"CollectedY", corner.CollectedY);
		this.writeDoubleVars(label+"CollectedZ", corner.CollectedZ);
		
		this.writeDoubleVars(label+"ClusterX", corner.ClusterX);
		this.writeDoubleVars(label+"ClusterY", corner.ClusterY);
		this.writeDoubleVars(label+"ClusterZ", corner.ClusterZ);
		
		this.writePoints(label+"Point", corner.PointX, corner.PointY, corner.PointZ);
		
		this.writeDoubleVars(label+"CollectedNormalX", corner.CollectedNormalX);
		this.writeDoubleVars(label+"CollectedNormalY", corner.CollectedNormalY);
		this.writeDoubleVars(label+"CollectedNormalZ", corner.CollectedNormalZ);
		
		this.writeDoubleVars(label+"ClusterNormalX", corner.ClusterNormalX);
		this.writeDoubleVars(label+"ClusterNormalY", corner.ClusterNormalY);
		this.writeDoubleVars(label+"ClusterNormalZ", corner.ClusterNormalZ);
		
		this.writePoints(label+"NormalPoint", corner.NormalPointX, corner.NormalPointY, corner.NormalPointZ);
	}
	
	public void writeMatrix(DenseMatrix64F m, String label)
	{
		//this.writeDoubleVars(label,m.data);
		write(label + " = [");
		for(int row=0;row<m.numRows;row++)
		{
			for(int col=0;col<m.numCols;col++)
			{
				write(" "+m.get(row, col));
			}
			write(";");
		}
		write("] \n");
	}
	
	/**
	 * Frontend to the log writing function. 
	 * Initializes, writes, closes file
	 */
	public void writeLog() {
		//logStatus=LogStatus.IDLE;
		// init the output file
		FileWriter fstream = null;
		try {
			fstream = new FileWriter(this.logfile);
		} catch (IOException e) {
			e.printStackTrace();
			//logger.fatal(e.getMessage());
			System.exit(1);
		}
		this.outfile = new BufferedWriter(fstream);
		
		writeCorner(topRight, "topRight");
		writeCorner(topLeft, "topLeft");
		writeCorner(botLeft, "botLeft");
		writeCorner(botRight, "botRight");
		

		writeMatrix(this.transformMatrix, "transformMatrix");
		writeMatrix(this.calcZTransform,  "palmNormalTransform");
		// close outfile
		try {
			this.outfile.close();
		} catch (IOException e) {
			e.printStackTrace();
			//logger.fatal(e.getMessage());
			System.exit(1);
			
		}
	}
	
}

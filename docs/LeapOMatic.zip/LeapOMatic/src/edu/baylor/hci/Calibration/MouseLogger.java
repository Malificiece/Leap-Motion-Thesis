package edu.baylor.hci.Calibration;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import edu.baylor.hci.LeapOMatic.MFileLogger;
import edu.baylor.hci.LeapOMatic.PositionLog.LogStatus;

/**
 * this Class simply logs the position of the pointer device actions and writes it to a file.
 * The actions are NOT hooked to the mouse or pointer. The actions need to be called manually. 
 * 
 * @author Alvin
 *
 */

public class MouseLogger extends MFileLogger {
	/** Class Constants **/
	/* what distance (in pixels) needed to exceed before its actually added to the list. Reduces noise. */ 
	private static final int DISTANCE_THRESHOLD = 25;

	/** Object Vars **/
	// position and time
	private ArrayList<Integer> mouseX = new ArrayList<Integer>();
	private ArrayList<Integer> mouseY = new ArrayList<Integer>();
	private ArrayList<Long> mouseTime = new ArrayList<Long>();
	// the distance here indicates the full path traversed between and X and Y and not the simple Eucledian distance
	private ArrayList<Integer> distanceMoved = new ArrayList<Integer>();
	private ArrayList<Long> distanceMovedStart = new ArrayList<Long>();
	private ArrayList<Long> distanceMovedEnd = new ArrayList<Long>();
	// Coordinates where a click occured
	private ArrayList<Integer> mouseClickPosX= new ArrayList<Integer>();
	private ArrayList<Integer> mouseClickPosY= new ArrayList<Integer>();
	private ArrayList<Long> mouseClickTime= new ArrayList<Long>(); //unixTimestamp
	// Coordinates where a MousePress action occurred. Not the same as Click
	private ArrayList<Integer> mousePressX = new ArrayList<Integer>();
	private ArrayList<Integer> mousePressY = new ArrayList<Integer>();
	private ArrayList<Long> mousePressTime= new ArrayList<Long>(); //unixTimestamp
	// Coordinates where a MouseRelease action occurred. Logically follows a MousePress
	private ArrayList<Integer> mouseReleaseX = new ArrayList<Integer>();
	private ArrayList<Integer> mouseReleaseY = new ArrayList<Integer>();
	private ArrayList<Long> mouseReleaseTime= new ArrayList<Long>(); //unixTimestamp

	private int distance=0;
	private boolean isCalcDistance=false;
	// Logger as usual. 
	final static Logger logger = Logger.getLogger(MouseLogger.class);
	
	public MouseLogger(String logfilePrefix) {
		this.setFilePrefix(logfilePrefix);
	}

	/**
	 * Frontend to the log writing function. 
	 * Initializes, writes, closes file
	 */
	public void writeLog() {

		// write my comments at the top of the file
		this.writeComments();
		// write my vars
		this.writeIntegerVars("mouseX", mouseX);
		this.writeIntegerVars("mouseY", mouseY);
		this.writeLongVars("mouseTime", mouseTime);
		
		this.writeIntegerVars("mouseClickX", mouseClickPosX);
		this.writeIntegerVars("mouseClickY", mouseClickPosY);
		this.writeLongVars("mouseClickTime", mouseClickTime);
		
		this.writeIntegerVars("mousePressX", mousePressX);
		this.writeIntegerVars("mousePressY", mousePressY);
		this.writeLongVars("mousePressTime", mousePressTime);
		
		this.writeIntegerVars("mouseReleaseX", mouseReleaseX);
		this.writeIntegerVars("mouseReleaseY", mouseReleaseY);
		this.writeLongVars("mouseReleaseTime", mouseReleaseTime);
		
		this.writeIntegerVars("distanceMoved", distanceMoved);
		this.writeLongVars("distanceMovedStart", distanceMovedStart);
		this.writeLongVars("distanceMovedEnd", distanceMovedEnd);
		
		// clear arrays
		clearArrays();
		logger.info("Log successfully written");

	}

	/**
	 * when called, we will start summing the entire distance covered by the mouse cursor 
	 * sets the distance=0(used to sum the distance), isSummingDistance=true indicating that we are ready to start summing, and adds the current time to distanceMovedStart
	 */
	public void startCalcDistance()
	{
		// reset the distance
		distance=0;
		// set the status flag
		isCalcDistance=true;
		distanceMovedStart.add(System.currentTimeMillis());
	}
	
	/**
	 * sets isCalcDistance to false meaning that we do not wish to sum for a moment, adds the distance that was summed to distanceMoved and adds the timeStamp to distanceMovedEnd
	 */
	public void endCalcDistance()
	{
		isCalcDistance=false;
		distanceMovedEnd.add(System.currentTimeMillis());
		distanceMoved.add(distance);
	}
	
	/**
	 * Clearing the arrays means that this object can be "reused"
	 * which is not impossible, but a bad idea because the filename does not change.
	 * To force this to fail hard, we just set all these vars to null so that they cannot be reused. 
	 */
	public void clearArrays()
	{
		mouseX = null;
		mouseY = null;
		mouseTime = null;
		mouseClickPosX = null;
		mouseClickPosY = null;
		mouseClickTime = null;
		
		mousePressX = null;
		mousePressY = null;
		mousePressTime = null;
		
		mouseReleaseX = null;
		mouseReleaseY = null;
		mouseReleaseTime = null;
	}

	/**
	 * Adds the X and Y locations in Pixels. 
	 * But these locations are only recorded if there's a Euclidean distance of 5 pixels or more between them
	 * @param x
	 * @param y
	 */
	public void addMouseXY(int x, int  y)
	{
		if(this.getLogStatus() ==LogStatus.START)
		{
			// if this is the first entry, then just add and move on. 
			if(mouseX.size() == 0) {
				mouseX.add(x);
				mouseY.add(y);
				mouseTime.add(System.currentTimeMillis());	
			} else {
				// so its not the first entry, we'll just store the previous numbers for later.. 
				int prevX = mouseX.get(mouseX.size()-1);
				int prevY = mouseY.get(mouseY.size()-1);
				int distanceTravelled = this.getDistance(x, y, prevX, prevY); 
				
				/* this is critical : 
				 * We ONLY perform the logging if the distance is more than the threshold.  
				 */
				if(distanceTravelled >= DISTANCE_THRESHOLD) {
					// do the usual logging: X, Y, Time. 
					mouseX.add(x);
					mouseY.add(y);
					mouseTime.add(System.currentTimeMillis());
					// if I'm supposed to, then I'll log the distance
					if(this.isCalcDistance) this.distance+=distanceTravelled;
				}
			}
		}
	}
	
	public void addMouseClick(int x, int y)
	{
		if(this.getLogStatus() == LogStatus.START)
		{
			mouseClickPosX.add(x);
			mouseClickPosY.add(y);
			mouseClickTime.add(System.currentTimeMillis());
		}
	}
	
	public void addMousePress(int x, int y)
	{
		
		if(this.getLogStatus() == LogStatus.START)
		{
			mousePressX.add(x);
			mousePressY.add(y);
			mousePressTime.add(System.currentTimeMillis());
		}
	}
	
	public void addMouseRelease(int x, int y)
	{
		if(this.getLogStatus() ==LogStatus.START)
		{
			mouseReleaseX.add(x);
			mouseReleaseY.add(y);
			mouseReleaseTime.add(System.currentTimeMillis());
		}
	}
	/**
	 * Returns the euclidean distance between 2 points. 
	 * Uses integers because of the context: we measure in Pixels, floating precision is pointless
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 * @return euclidean Distance 
	 */
	private int getDistance(int x1, int y1, int x2, int y2) {
		int xDist = x1 - x2;
		int yDist = y1 - y2; 
		return (int) Math.sqrt(xDist * xDist + yDist * yDist);	
	}
	
}

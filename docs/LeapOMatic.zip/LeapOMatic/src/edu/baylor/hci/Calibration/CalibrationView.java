package edu.baylor.hci.Calibration;


import java.awt.GridLayout;
import java.awt.TextArea;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CalibrationView extends JPanel {
	private static final long serialVersionUID = 4589925884327869254L;

	private TextArea message = null;
	private JButton topLeft = null;
	private JButton botLeft = null;
	private JButton topRight = null;
	private JButton botRight = null;
	
	public enum CalibrationButtons 
	{
		TOP_RIGHT,
		TOP_LEFT,
		BOT_LEFT,
		BOT_RIGHT,
		DISABLE,
	}
	public CalibrationButtons activeButton=null;
	public CalibrationView()
	{
		
		setLayout(new GridLayout(3, 3));
		topLeft = new JButton("Top Left");
		botLeft = new JButton("Bottom Left");
		topRight = new JButton("Top Right");
		botRight = new JButton("Bottom Right");
		
		disableAllButtons();
		message = new TextArea("CALIBRATE TOP RIGHT");
		add(topLeft);
		add(new JLabel(""));
		add(topRight);
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		add(botLeft);
		add(new JLabel(""));
		add(botRight);
		
	}
	public void setMessage(String message)
	{
		this.message.setText(message);
	}
	
	/**
	 * Show the 4 calibration points based on input  
	 * @param button
	 */
	public void toggleVisibility(CalibrationButtons button)
	{
		if(button==CalibrationButtons.TOP_LEFT)
		{
			disableAllButtons();
			topLeft.setVisible(true);
			
		}
		else if(button==CalibrationButtons.TOP_RIGHT)
		{
			disableAllButtons();
			topRight.setVisible(true);
		}
		else if(button ==CalibrationButtons.BOT_LEFT)
		{
			disableAllButtons();
			botLeft.setVisible(true);
		}
		else if(button ==CalibrationButtons.BOT_RIGHT)
		{
			disableAllButtons();
			botRight.setVisible(true);
		}
		else if(button == CalibrationButtons.DISABLE)
		{
			disableAllButtons();
		}
	}
	
	private void disableAllButtons()
	{
		topLeft.setVisible(false);
		topRight.setVisible(false);
		botLeft.setVisible(false);
		botRight.setVisible(false);
	}
}

package edu.baylor.hci.LeapOMatic;

public class Settings {
	public final static String DATE_FORMAT = "yyyyMMdd_kkmm";
	public final static String LOGFILE_DIR = "log";
	public final static boolean EXPERIMENT_DEBUG = true;
}

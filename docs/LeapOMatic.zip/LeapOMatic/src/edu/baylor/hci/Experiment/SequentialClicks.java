package edu.baylor.hci.Experiment;

import java.awt.GraphicsEnvironment;
import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.Timer;
import javax.swing.WindowConstants;
import org.apache.log4j.Logger;
import edu.baylor.hci.LeapOMatic.TouchPoints;
import edu.baylor.hci.LeapOMatic.PositionLog.LogStatus;



public class SequentialClicks extends JFrame implements ActionListener, KeyEventDispatcher {
	private static final long serialVersionUID = 2858671353438527428L;
	private SequentialClicksView view=null;
	private Timer timer=null;
	private JFrame fullscreenFrame=null; 
	private ExperimentLogger expLogger = null;
	
	private static final int INITIAL_DELAY = 0;
	private static final int TIMER_INTERVAL = 1000;
	public static final int gameDuration = 100;
	public final int countDownTicks=5;
	public int score=0;
	public int ticks=0;
	private final int ROWS=9;
	private final int COLS=10;

    private static final Logger logger = Logger.getLogger(SequentialClicks.class);
    
	public SequentialClicks()
	{
		/*try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		 
 		fullscreenFrame= new JFrame();
 		fullscreenFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
 		fullscreenFrame.setUndecorated(true);
 		fullscreenFrame.setResizable(false);
 		fullscreenFrame.validate();
 		GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().setFullScreenWindow(fullscreenFrame);
 		
 		addKeyListener();
	    expLogger = new ExperimentLogger("seqClicks"+TouchPoints.getNameToAppend());
 		view= new SequentialClicksView(ROWS, COLS, this);
 		fullscreenFrame.add(view);
	    
	    timer= new Timer(TIMER_INTERVAL, this);
	    timer.setInitialDelay(INITIAL_DELAY);
	    timer.start();
	    
	}
	/**
	 * attaches a listener to the keyboard for every key press, release and typed. Any of these will trigger the dispatchKeyEvent(e)
	 */
	private void addKeyListener() {
		KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
 		manager.addKeyEventDispatcher(this);
	}
	
	public void exit()
	{	//don't call this too quickly after the stopGame(). Give it a second or two
		this.dispose();
		fullscreenFrame.dispose();
	}
	
	public void stopGame()
	{		
		/*** 
		TouchPoints.getMouseLogger().writeLog();
		TouchPoints.getMouseLogger().setLogStatus(LogStatus.STOP);
		***/
		expLogger.setEndTime(System.currentTimeMillis());
		expLogger.writeLog();
		expLogger.setLogStatus(LogStatus.STOP); //starting Logger
		timer.stop();
		
	}
	
	private void startGame() {
		view.toggleExperimentOrderCell();
		/*** TouchPoints.getMouseLogger().setLogStatus(LogStatus.START); ***/
		expLogger.setLogStatus(LogStatus.START); //starting Logger
		expLogger.setStartTime(System.currentTimeMillis());
	}
	
	public ExperimentLogger getExperimentLogger()
	{
		return expLogger;
	}
	
	public void incrementScore()
	{
		score++;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(ticks==0)
		{
			logger.info("Starting ExperimentLog");
		}
		if(ticks<5)
		{
			view.setStatusCell(5-ticks);
		}
		else if(ticks==countDownTicks)
		{
			startGame();
			
		}
		else
		{
			view.setStatusCell(score, ticks-countDownTicks);
		}
		ticks++;
	}
	
	

	@Override
	public boolean dispatchKeyEvent(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode()==KeyEvent.VK_ESCAPE)
		{
			 if (e.getID() == KeyEvent.KEY_RELEASED){
				 exit();
			 }
		}
		return false;
	}
	

	
}

package edu.baylor.hci.Experiment;

import java.util.ArrayList;

import edu.baylor.hci.Experiment.Cell.Type;





/**
 * Used to construct the parameters for each experiment type so that we can consolidate the trials into one file
 * @author guinness
 *
 */
class Cell
{
	
	private int row, col;
	private Type type;
	public enum Type { NONE, LEFT_CLICK, RIGHT_CLICK }
	public Cell(int row, int col, Type type){
		this.row=row;
		this.col=col;
		this.type=type;
	}
}

public class ExpConfig {
	private static ArrayList<Cell> experimentOrder;
	
	/**
	 * takes an integer corresponding to the experimentOrder that the function will return
	 * 
	 * 0 => Debug Order, 1 => first experiment order, 2 => second experiment order, 3 => third experiment order, 4 => fourth experiment order
	 * 
	 * @param order
	 * @return
	 * @throws Exception 
	 */
	public static ArrayList<Cell> getExperimentOrder(int order) throws Exception
	{
		switch (order)	{
		case 0:
			setDebugExperimentOrder();
			break;
		case 1:
			setProductionExperimentOrder1();
			break;
		case 2:
			setProductionExperimentOrder2();
			break;
		case 3:
			setProductionExperimentOrder3();
			break;
		case 4:
			setProductionExperimentOrder4();
			break;
		default:
			throw new Exception(order+" order not found");
		}
		return experimentOrder;
	}
	
	private static void setDebugExperimentOrder()
	{
		experimentOrder = new ArrayList<Cell>();
		experimentOrder.add(new Cell(0, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(9, 15, Type.LEFT_CLICK));
	}
	/**
	 * sets a unique trial ordering for the experiment also specifies which button will be utilized per trial. 
	 */
	private static void setProductionExperimentOrder1()
	{
		experimentOrder = new ArrayList<Cell>();
		/*
		 * 1-10
		 */
		experimentOrder.add(new Cell(4, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 9, Type.LEFT_CLICK));
		/*
		 * 11-20
		 */
		experimentOrder.add(new Cell(4, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 3, Type.LEFT_CLICK));
		/*
		 * 21-30
		 */
		experimentOrder.add(new Cell(0, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 7, Type.LEFT_CLICK));
		/*
		 * 31-40
		 */
		experimentOrder.add(new Cell(3, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		/*
		 * 41-50
		 */
		experimentOrder.add(new Cell(8, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 8, Type.LEFT_CLICK));
		/*
		 * 51-60
		 */
		experimentOrder.add(new Cell(4, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 4, Type.LEFT_CLICK));
		/*
		 * 61-63
		 */
		experimentOrder.add(new Cell(7, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 2, Type.LEFT_CLICK));
		
	}
	private static void setProductionExperimentOrder2()
	{
		experimentOrder = new ArrayList<Cell>();
		/*
		 * 1-10
		 */
		experimentOrder.add(new Cell(4, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 9, Type.LEFT_CLICK));
		/*
		 * 11-20
		 */
		experimentOrder.add(new Cell(4, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 3, Type.LEFT_CLICK));
		/*
		 * 21-30
		 */
		experimentOrder.add(new Cell(0, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 7, Type.LEFT_CLICK));
		/*
		 * 31-40
		 */
		experimentOrder.add(new Cell(3, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		/*
		 * 41-50
		 */
		experimentOrder.add(new Cell(8, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 8, Type.LEFT_CLICK));
		/*
		 * 51-60
		 */
		experimentOrder.add(new Cell(4, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 4, Type.LEFT_CLICK));
		/*
		 * 61-63
		 */
		experimentOrder.add(new Cell(7, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 2, Type.LEFT_CLICK));
		
	}
	private static void setProductionExperimentOrder3()
	{
		experimentOrder = new ArrayList<Cell>();
		/*
		 * 1-10
		 */
		experimentOrder.add(new Cell(4, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 9, Type.LEFT_CLICK));
		/*
		 * 11-20
		 */
		experimentOrder.add(new Cell(4, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 3, Type.LEFT_CLICK));
		/*
		 * 21-30
		 */
		experimentOrder.add(new Cell(0, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 7, Type.LEFT_CLICK));
		/*
		 * 31-40
		 */
		experimentOrder.add(new Cell(3, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		/*
		 * 41-50
		 */
		experimentOrder.add(new Cell(8, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 8, Type.LEFT_CLICK));
		/*
		 * 51-60
		 */
		experimentOrder.add(new Cell(4, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 4, Type.LEFT_CLICK));
		/*
		 * 61-63
		 */
		experimentOrder.add(new Cell(7, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 2, Type.LEFT_CLICK));
		
	}
	private static void setProductionExperimentOrder4()
	{
		experimentOrder = new ArrayList<Cell>();
		/*
		 * 1-10
		 */
		experimentOrder.add(new Cell(4, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 9, Type.LEFT_CLICK));
		/*
		 * 11-20
		 */
		experimentOrder.add(new Cell(4, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 3, Type.LEFT_CLICK));
		/*
		 * 21-30
		 */
		experimentOrder.add(new Cell(0, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 7, Type.LEFT_CLICK));
		/*
		 * 31-40
		 */
		experimentOrder.add(new Cell(3, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 0, Type.LEFT_CLICK));
		/*
		 * 41-50
		 */
		experimentOrder.add(new Cell(8, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(1, 9, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 0, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(8, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 5, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(7, 4, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 8, Type.LEFT_CLICK));
		/*
		 * 51-60
		 */
		experimentOrder.add(new Cell(4, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 1, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(4, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 2, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 6, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(0, 3, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(5, 7, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(2, 4, Type.LEFT_CLICK));
		/*
		 * 61-63
		 */
		experimentOrder.add(new Cell(7, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(3, 8, Type.LEFT_CLICK));
		experimentOrder.add(new Cell(6, 2, Type.LEFT_CLICK));
		
	}
}

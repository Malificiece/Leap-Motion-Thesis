package edu.baylor.hci.Experiment;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import edu.baylor.hci.LeapOMatic.Settings;

public class SequentialClicksView extends JPanel implements MouseListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8051026090568327533L;
	private int ROWS;
	private int COLS;
	private boolean hasEntered=false;
	private long enterTime = 0;
	private static final boolean GRID_VISIBILE=false;
	private JLabel statusCell=null;
	private JComponent grid[][];
	private SequentialClicks controller=null;
	
	private static final Color CELL_BORDER_COLOR = Color.RED; //border color of the cells in the grid
	private static final Color CELL_FOREGROUND_COLOR = Color.BLACK; //text color of the cells in the grid
	private static final Color CELL_BACKGROUND_COLOR = Color.WHITE; //background color of the cells in the grid
	private static final Color STATUS_FOREGROUND_COLOR = Color.black;
	private static final Color STATUS_BACKGROUND_COLOR = Color.WHITE;
	
	class Cell
	{
		public int row, col;
		public Cell(int row, int col){
			this.row=row;
			this.col=col;
		}
	}
	private ArrayList<Cell> experimentOrder;
	
	public SequentialClicksView(int rows, int cols,SequentialClicks controller)
	{	
		JButton temp=null;
		this.controller=controller;
		ROWS=rows;
		COLS=cols;
		
		grid= new JButton[ROWS][COLS];
		setLayout(new GridLayout(ROWS, COLS));
		addMouseListener(this);
		for(int i=0;i<ROWS;i++)
		{
			for(int j=0;j<COLS;j++)
			{
				if(i==5 && j==4) //status Cell
				{
					statusCell = new JLabel("<html><h2>Status</h2></html>");
					statusCell.setVisible(true);
					//statusCell.setEnabled(false);
					statusCell.setHorizontalAlignment(SwingConstants.CENTER);
					statusCell.setOpaque(true);
					statusCell.setForeground(STATUS_FOREGROUND_COLOR);
					statusCell.setBackground(STATUS_BACKGROUND_COLOR);
					add(statusCell);
				}
				else
				{
					temp=new JButton("BUTTONS");
					temp.addMouseListener(this);
					temp.setBackground(Color.white);
					temp.setVisible(GRID_VISIBILE);
					temp.setForeground(CELL_FOREGROUND_COLOR);
					temp.setBackground(CELL_BACKGROUND_COLOR);
					temp.setBorder(BorderFactory.createLineBorder(CELL_BORDER_COLOR, 5));
					grid[i][j] = temp;
					add(grid[i][j]);
				}
			}
		}
		if(Settings.EXPERIMENT_DEBUG)
		{
			setDebugExperimentOrder();
		}
		else
		{
			setProductionExperimentOrder();
		}
	}
	/**
	 * Be careful not to add the statusCell(Row/2, col/2) to this order as it should not let you proceed further
	 * 
	 * Consider putting this into the controller
	 * TODO add robustness to not allow you to add this cell
	 */
	private void setDebugExperimentOrder()
	{
		experimentOrder = new ArrayList<Cell>();
		experimentOrder.add(new Cell(0, 0));
		experimentOrder.add(new Cell(6, 6));
		experimentOrder.add(new Cell(1,1));
		
		
	}
	
	private void setProductionExperimentOrder()
	{
		experimentOrder = new ArrayList<Cell>();
		/*
		 * 1-10
		 */
		experimentOrder.add(new Cell(4, 4));
		experimentOrder.add(new Cell(4, 3));
		experimentOrder.add(new Cell(8, 3));
		experimentOrder.add(new Cell(8, 6));
		experimentOrder.add(new Cell(4, 6));
		experimentOrder.add(new Cell(4, 4));
		experimentOrder.add(new Cell(0, 4));
		experimentOrder.add(new Cell(3, 2));
		experimentOrder.add(new Cell(0, 0));
		experimentOrder.add(new Cell(8, 9));
		/*
		 * 11-20
		 */
		experimentOrder.add(new Cell(4, 9));
		experimentOrder.add(new Cell(4, 0));
		experimentOrder.add(new Cell(0, 9));
		experimentOrder.add(new Cell(8, 0));
		experimentOrder.add(new Cell(2, 9));
		experimentOrder.add(new Cell(6, 0));
		experimentOrder.add(new Cell(6, 9));
		experimentOrder.add(new Cell(2, 0));
		experimentOrder.add(new Cell(1, 6));
		experimentOrder.add(new Cell(7, 3));
		/*
		 * 21-30
		 */
		experimentOrder.add(new Cell(0, 7));
		experimentOrder.add(new Cell(8, 2));
		experimentOrder.add(new Cell(0, 1));
		experimentOrder.add(new Cell(5, 9));
		experimentOrder.add(new Cell(3, 9));
		experimentOrder.add(new Cell(3, 5));
		experimentOrder.add(new Cell(6, 5));
		experimentOrder.add(new Cell(3, 7));
		experimentOrder.add(new Cell(6, 3));
		experimentOrder.add(new Cell(6, 7));
		/*
		 * 31-40
		 */
		experimentOrder.add(new Cell(3, 3));
		experimentOrder.add(new Cell(2, 7));
		experimentOrder.add(new Cell(8, 0));
		experimentOrder.add(new Cell(0, 0));
		experimentOrder.add(new Cell(7, 1));
		experimentOrder.add(new Cell(0, 2));
		experimentOrder.add(new Cell(7, 9));
		experimentOrder.add(new Cell(8, 7));
		experimentOrder.add(new Cell(8, 4));
		experimentOrder.add(new Cell(8, 0));
		/*
		 * 41-50
		 */
		experimentOrder.add(new Cell(8, 9));
		experimentOrder.add(new Cell(1, 2));
		experimentOrder.add(new Cell(1, 9));
		experimentOrder.add(new Cell(7, 0));
		experimentOrder.add(new Cell(0, 5));
		experimentOrder.add(new Cell(8, 5));
		experimentOrder.add(new Cell(7, 5));
		experimentOrder.add(new Cell(7, 6));
		experimentOrder.add(new Cell(7, 4));
		experimentOrder.add(new Cell(0, 8));
		/*
		 * 51-60
		 */
		experimentOrder.add(new Cell(4, 1));
		experimentOrder.add(new Cell(4, 8));
		experimentOrder.add(new Cell(6, 1));
		experimentOrder.add(new Cell(4, 2));
		experimentOrder.add(new Cell(5, 2));
		experimentOrder.add(new Cell(3, 6));
		experimentOrder.add(new Cell(5, 8));
		experimentOrder.add(new Cell(0, 3));
		experimentOrder.add(new Cell(5, 7));
		experimentOrder.add(new Cell(2, 4));
		/*
		 * 61-63
		 */
		experimentOrder.add(new Cell(7, 8));
		experimentOrder.add(new Cell(3, 8));
		experimentOrder.add(new Cell(6, 2));
		
	}
	
	public void setStatusCell(int countDownInteger)
	{
		statusCell.setText("<html><h1>Game Starts: "+countDownInteger +"</h1> </html>");
	}
	
	public void setStatusCell(int score, int time)
	{
		statusCell.setText(String.format("<html><h1>score:%d <br /> time:%d </h1> </html>", score, time));
	}
	
	public void toggleCellVisibility(int row, int col)
	{
		grid[row][col].setVisible(!grid[row][col].isVisible());
	}
	
	public void toggleRandomCell() {
		Random rand = new Random();
		toggleCellVisibility(rand.nextInt(ROWS), rand.nextInt(COLS));
	}
	
	public void toggleExperimentOrderCell()
	{	
		if(experimentOrder.size()>0)
		{
			toggleCellVisibility(experimentOrder.get(0).row, experimentOrder.get(0).col);
			experimentOrder.remove(0);
		}		
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		
	}
	/**
	 * This function is called whenever the user enters the button to be clicked area. If it is the first time the user has hovered over this button we 
	 * log the time for hoverTime later.
	 */
	@Override
	public void mouseEntered(MouseEvent e) {
		if(e.getSource() instanceof JButton && !hasEntered)
		{	
			hasEntered=true;
			enterTime=System.currentTimeMillis();
		}
	}
	
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Will be toggled on mousePress, if the press occurs on a button then it is a true positive, if it occurs somewhere on the panel it is a false positive.
	 * if(e.getSource() instanceof JButton) => we log the position and hoverTime, check if the game is over and stop if so, otherwise sets the last button's 
	 * visibility to false and toggle's the next button to Click. Also updates the score in the status Cell.
	 * else => we log the falsePositive click and do nothing else.
	 * 
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		if(e.getSource() instanceof JButton) //true positive click
		{
			long time = System.currentTimeMillis();
			controller.getExperimentLogger().addHoverTime(enterTime, time);
			controller.getExperimentLogger().addTruePosXY(e.getXOnScreen(), e.getYOnScreen());
			if(experimentOrder.size()<1)
			{
				controller.stopGame();
			}
			JButton temp=(JButton)e.getSource();
			temp.setVisible(false);
			toggleExperimentOrderCell();

			controller.incrementScore();
			hasEntered=false;
			setStatusCell(controller.score, controller.ticks-controller.countDownTicks);
			//timer.stop();
		}
		else //false positive click
		{
			controller.getExperimentLogger().addFalsePosXY(e.getXOnScreen(), e.getYOnScreen());
		}
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}

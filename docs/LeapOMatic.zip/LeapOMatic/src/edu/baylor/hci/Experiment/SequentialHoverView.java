package edu.baylor.hci.Experiment;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;

import edu.baylor.hci.LeapOMatic.Settings;

public class SequentialHoverView extends JPanel implements MouseListener, ActionListener, MouseMotionListener{
	/* Class Constants */
	// border color of the cells in the grid
	private static final Color CELL_BORDER_COLOR = Color.RED;
	// text color of the cells in the grid
	private static final Color CELL_FOREGROUND_COLOR = Color.BLACK; 
	// background color of the cells in the grid
	private static final Color CELL_BACKGROUND_COLOR = Color.WHITE;
	// font color inside the cells
	private static final Color STATUS_FOREGROUND_COLOR = Color.BLACK;
	// cell color
	private static final Color STATUS_BACKGROUND_COLOR = Color.GRAY;
	// window color
	private static final Color WINDOW_BACKGROUND_COLOR = Color.BLACK;
	// how long need to hover
	private static final int HOVER_DURATION = 500;
	private static final int TIMER_INITIAL_DELAY = 0;
	// Should the grid lines be visible?
	private static final boolean GRID_VISIBILE = false;
	
	// prereq sUID
	private static final long serialVersionUID = 8051026090568327533L;
	
	/** declare global variables used here. **/
	// control variable set true when cursor enters widget
	private boolean hasEntered;
	private long enterTime;
	private JLabel statusCell;
	private JComponent widgets[][];
	private JComponent panels[][];
	private SequentialHover controller;
	private int hoverX, hoverY;
	private int ticks;
	private JButton clickButton; //button to Click
	
	class Cell
	{
		private int row, col;
		public Cell(int row, int col){
			this.row=row;
			this.col=col;
		}
	}
	
	private ArrayList<Cell> experimentOrder;
	private Timer timer;
	
	public SequentialHoverView(SequentialHover controller)
	{	

		// set up cursor
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Image image;
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		try {
			image = ImageIO.read(classLoader.getResourceAsStream("crosshair.gif"));
			// windows requires the cursor to be a 32x32px image MAX. 
			// So we place the hotspot right in the center
			Point hotspot = new Point(16, 16);
	        Cursor cursor = toolkit.createCustomCursor(image, hotspot, "cursor");
	        this.setCursor(cursor);
		} catch (IOException e) {
			// TODO loggit
			e.printStackTrace();
		}
        
		this.setBackground(WINDOW_BACKGROUND_COLOR);
		timer= new Timer(HOVER_DURATION, this);
	    timer.setInitialDelay(TIMER_INITIAL_DELAY);
		JButton temp=null;
		this.controller=controller;
		
		widgets = new JButton[controller.getRowCount()][controller.getColCount()];
		panels = new JPanel[controller.getRowCount()][controller.getColCount()];
		
		setLayout(new GridLayout(controller.getRowCount(), controller.getColCount()));	
		addMouseListener(this);
		addMouseMotionListener(this);
		for(int i=0;i<controller.getRowCount();i++)
		{
			for(int j=0;j<controller.getColCount();j++)
			{
				/** add buttons everywhere except on the status cell  **/
				if(i == controller.getStatuscellRow() && j == controller.getStatuscellCol()) //status Cell
				{
					statusCell = new JLabel("<html><h2>Status</h2></html>");
					statusCell.setVisible(true);
					//statusCell.setEnabled(false);
					statusCell.setHorizontalAlignment(SwingConstants.CENTER);
					statusCell.setOpaque(true);
					statusCell.setForeground(STATUS_FOREGROUND_COLOR);
					statusCell.setBackground(STATUS_BACKGROUND_COLOR);
					add(statusCell);
				}
				else
				{
					// create the panel
					JPanel tmpanel = new JPanel();
					tmpanel.setBackground(WINDOW_BACKGROUND_COLOR);
					panels[i][j] = tmpanel;
					
					// add the panel to the grid
					this.add(panels[i][j]);
					
					// create the widget
					temp=new JButton("");
					temp.addMouseListener(this);
					temp.setBackground(Color.white);
					temp.setVisible(GRID_VISIBILE);
					temp.setForeground(CELL_FOREGROUND_COLOR);
					temp.setBackground(CELL_BACKGROUND_COLOR);
					temp.setBorder(BorderFactory.createLineBorder(CELL_BORDER_COLOR, 5));
					temp.setPreferredSize(new Dimension(100, 100));
					widgets[i][j] = temp;
					//add(widgets[i][j]);
					panels[i][j].add(widgets[i][j]);
				}
			}
		}
		if(Settings.EXPERIMENT_DEBUG)
		{
			setDebugExperimentOrder();
		}
		else
		{
			setProductionExperimentOrder();
		}
	}
	
	/**
	 * If Debug mode is set (edu.baylor.hci.lom.Settings), then we will use this Profile. It's shorter, makes it easier to check for completion, etc
	 * 
	 * Be careful not to add the statusCell(Row/2, col/2) to this order as it should not let you proceed further
	 * Consider putting this into the controller
	 * TODO add robustness to not allow you to add the status cell 
	 */
	private void setDebugExperimentOrder()
	{
		experimentOrder = new ArrayList<Cell>();
		experimentOrder.add(new Cell(0, 0));
		experimentOrder.add(new Cell(6, 6));
		experimentOrder.add(new Cell(controller.getRowCount() - 1, controller.getColCount() - 1));
		
		
	}
	
	private void setProductionExperimentOrder()
	{
		experimentOrder = new ArrayList<Cell>();
		/*
		 * 1-10
		 */
		experimentOrder.add(new Cell(4, 4));
		experimentOrder.add(new Cell(4, 3));
		experimentOrder.add(new Cell(8, 3));
		experimentOrder.add(new Cell(8, 6));
		experimentOrder.add(new Cell(4, 6));
		experimentOrder.add(new Cell(4, 4));
		experimentOrder.add(new Cell(0, 4));
		experimentOrder.add(new Cell(3, 2));
		experimentOrder.add(new Cell(0, 0));
		experimentOrder.add(new Cell(8, 9));
		/*
		 * 11-20
		 */
		experimentOrder.add(new Cell(4, 9));
		experimentOrder.add(new Cell(4, 0));
		experimentOrder.add(new Cell(0, 9));
		experimentOrder.add(new Cell(8, 0));
		experimentOrder.add(new Cell(2, 9));
		experimentOrder.add(new Cell(6, 0));
		experimentOrder.add(new Cell(6, 9));
		experimentOrder.add(new Cell(2, 0));
		experimentOrder.add(new Cell(1, 6));
		experimentOrder.add(new Cell(7, 3));
		/*
		 * 21-30
		 */
		experimentOrder.add(new Cell(0, 7));
		experimentOrder.add(new Cell(8, 2));
		experimentOrder.add(new Cell(0, 1));
		experimentOrder.add(new Cell(5, 9));
		experimentOrder.add(new Cell(3, 9));
		experimentOrder.add(new Cell(3, 5));
		experimentOrder.add(new Cell(6, 5));
		experimentOrder.add(new Cell(3, 7));
		experimentOrder.add(new Cell(6, 3));
		experimentOrder.add(new Cell(6, 7));
		/*
		 * 31-40
		 */
		experimentOrder.add(new Cell(3, 3));
		experimentOrder.add(new Cell(2, 7));
		experimentOrder.add(new Cell(8, 0));
		experimentOrder.add(new Cell(0, 0));
		experimentOrder.add(new Cell(7, 1));
		experimentOrder.add(new Cell(0, 2));
		experimentOrder.add(new Cell(7, 9));
		experimentOrder.add(new Cell(8, 7));
		experimentOrder.add(new Cell(8, 4));
		experimentOrder.add(new Cell(8, 0));
		/*
		 * 41-50
		 */
		experimentOrder.add(new Cell(8, 9));
		experimentOrder.add(new Cell(1, 2));
		experimentOrder.add(new Cell(1, 9));
		experimentOrder.add(new Cell(7, 0));
		experimentOrder.add(new Cell(0, 5));
		experimentOrder.add(new Cell(8, 5));
		experimentOrder.add(new Cell(7, 5));
		experimentOrder.add(new Cell(7, 6));
		experimentOrder.add(new Cell(7, 4));
		experimentOrder.add(new Cell(0, 8));
		/*
		 * 51-60
		 */
		experimentOrder.add(new Cell(4, 1));
		experimentOrder.add(new Cell(4, 8));
		experimentOrder.add(new Cell(6, 1));
		experimentOrder.add(new Cell(4, 2));
		experimentOrder.add(new Cell(5, 2));
		experimentOrder.add(new Cell(3, 6));
		experimentOrder.add(new Cell(5, 8));
		experimentOrder.add(new Cell(0, 3));
		experimentOrder.add(new Cell(5, 7));
		experimentOrder.add(new Cell(2, 4));
		/*
		 * 61-63
		 */
		experimentOrder.add(new Cell(7, 8));
		experimentOrder.add(new Cell(3, 8));
		experimentOrder.add(new Cell(6, 2));
		
	}
	
	public void setStatusCell(int countDownInteger)
	{
		statusCell.setText("<html><h1>Game Starts: "+countDownInteger +"</h1> </html>");
	}
	
	public void setStatusCell(int score, int time)
	{
		statusCell.setText(String.format("<html><h1>score:%d <br /> time:%d </h1> </html>", score, time));
	}
	
	public void toggleCellVisibility(int row, int col)
	{
		widgets[row][col].setVisible(!widgets[row][col].isVisible());
	}
	
	/**Toggles the next cell to be made visible. removes the cell from the experiment order, and starts the distance calculation for moving to the next cell.
	 * mouselog.startCalcDistance() being called here
	 */
	public void toggleExperimentOrderCell()
	{	
		if(experimentOrder.size()>0)
		{
			controller.mouseLog.startCalcDistance();
			toggleCellVisibility(experimentOrder.get(0).row, experimentOrder.get(0).col);
			experimentOrder.remove(0);
		}		
	}
	
	public void quit()
	{
		timer.stop();
		clickButton.setVisible(false);
		clickButton.setEnabled(false);
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
	}
	
	/**
	 * This function is called whenever the user enters the button to be clicked area. If it is the first time the user has hovered over this button we 
	 * log the time for hoverTime later.
	 */
	@Override
	public void mouseEntered(MouseEvent e) {
		if(e.getSource() instanceof JButton && !hasEntered)
		{	
			hasEntered=true;
			enterTime=System.currentTimeMillis();
			
		    timer.restart();
		    hoverX = e.getXOnScreen();
		    hoverY = e.getYOnScreen();
		    clickButton = (JButton) e.getSource();
		    
		}
	}
	
	@Override
	public void mouseExited(MouseEvent e) {
		if(hasEntered)
		{
			ticks=0;
			hasEntered=!hasEntered;
			timer.stop();
		}
		
	}
	
	
	@Override
	public void mousePressed(MouseEvent e) {
	}
	@Override
	public void mouseReleased(MouseEvent e) {
	}
	
	/**
	 * If the ticks is >0 then we know that we have hovered for 1 second because we restart the timer whenever we enter the button(hover).
	 * 		add hoverTime, and enterX, enterY, CALLS MOUSELOG.ENDCALCDISTANCE(), and calls toggleExperimentOrderCell() if the game is not over which in turn calls MOUSELOG.STARTCALCDISTANCE()
	 *  	increments the score and sets hasEntered to false for next hover
	 * else we incremment ticks
	 * 
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(ticks!=0)
		{
			long time = System.currentTimeMillis();
			controller.getExperimentLogger().addHoverTime(enterTime, time);
			controller.getExperimentLogger().addTruePosXY(hoverX, hoverY);
			controller.mouseLog.endCalcDistance();
			
			if(experimentOrder.size()<1)
			{	
				controller.stopGame();
			}
			
			clickButton.setVisible(false);
			toggleExperimentOrderCell();
	
			controller.incrementScore();
			hasEntered=false;
			//setStatusCell(controller.score, controller.ticks-controller.COUNTDOWN_TIMER);
			timer.stop();
			ticks=0;
		}
		else
		{
			ticks++;
		}
	}
	@Override
	public void mouseDragged(MouseEvent e) {
	}
	

	/**
	 * With every move of the cursor, send the coordinates to the mouse log
	 */
	@Override
	public void mouseMoved(MouseEvent e) {
		controller.mouseLog.addMouseXY(e.getXOnScreen(), e.getYOnScreen());
	}
	
}

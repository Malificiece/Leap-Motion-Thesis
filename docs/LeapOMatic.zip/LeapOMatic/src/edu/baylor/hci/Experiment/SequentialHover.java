package edu.baylor.hci.Experiment;

import java.awt.GraphicsEnvironment;
import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import javax.swing.JFrame;
import javax.swing.Timer;
import javax.swing.WindowConstants;
import org.apache.log4j.Logger;
import edu.baylor.hci.Calibration.MouseLogger;
import edu.baylor.hci.LeapOMatic.TouchPoints;
import edu.baylor.hci.LeapOMatic.PositionLog.LogStatus;



public class SequentialHover extends JFrame implements ActionListener, KeyEventDispatcher, MouseMotionListener {
	
	/** Class Constants **/
	// timers initial delay
	private static final int INITIAL_DELAY = 0;
	// time per tick. Set to 1 second because we need _Real_ Time. 
	private static final int TIMER_INTERVAL = 1000;
	// how long to countdown to start of game. 
	public static final int COUNTDOWN_TIMER = 5;
	// How many rows and columns - Public because the view will access this
	private static final int ROWS = 9;
	private static final int COLS = 11;
	// the position of the Status message. Remember starts from 0
	private static final int STATUSCELL_ROW = 4;
	private static final int STATUSCELL_COL = 5;
	

	// required sUID
	private static final long serialVersionUID = 2858671353438527428L;
	
	/** class global vars **/
	private SequentialHoverView view;
	private Timer timer;
	private JFrame fullscreenFrame;
	// the following will be used for every experiment. 
	private ExperimentLogger expLogger;
	public MouseLogger mouseLog;
	// current score. Init to 0
	public int score = 0;
	// init the ticks to the negative version of countdown
	public int ticks = -1 * COUNTDOWN_TIMER;

	// oblig logger
    private static final Logger logger = Logger.getLogger(SequentialHover.class);
    
	public SequentialHover()
	{
		 
 		fullscreenFrame= new JFrame();
 		fullscreenFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
 		fullscreenFrame.setUndecorated(true);
 		fullscreenFrame.setResizable(false);
 		fullscreenFrame.validate();
 		GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().setFullScreenWindow(fullscreenFrame);
 		
 		addKeyListener();
 		mouseLog = new MouseLogger("seqHover_mouseLog"+TouchPoints.getNameToAppend());
	    expLogger = new ExperimentLogger("seqHover_experimentLog"+TouchPoints.getNameToAppend());
 		view= new SequentialHoverView(this);
 		fullscreenFrame.add(view);
	    
	    timer= new Timer(TIMER_INTERVAL, this);
	    timer.setInitialDelay(INITIAL_DELAY);
	    timer.start();
	    
	}
	/**
	 * attaches a listener to the keyboard for every key press, release and typed. Any of these will trigger the dispatchKeyEvent(e)
	 */
	private void addKeyListener() {
		KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
 		manager.addKeyEventDispatcher(this);
	}
	
	public void exit()
	{
		this.dispose();
		fullscreenFrame.dispose();
	}
	
	public void stopGame()
	{		
		mouseLog.writeLog();
		mouseLog.setLogStatus(LogStatus.STOP);
		/*** 
		TouchPoints.getMouseLogger().writeLog();
		TouchPoints.getMouseLogger().setLogStatus(LogStatus.STOP);
		***/
		expLogger.setEndTime(System.currentTimeMillis());
		expLogger.writeLog();
		expLogger.setLogStatus(LogStatus.STOP); //starting Logger
		timer.stop();
		view.quit();
		
		
	}
	
	private void startGame() {
		view.toggleExperimentOrderCell();
		/*** TouchPoints.getMouseLogger().setLogStatus(LogStatus.START); ***/
		expLogger.setLogStatus(LogStatus.START); //starting Logger
		expLogger.setStartTime(System.currentTimeMillis());
		mouseLog.setLogStatus(LogStatus.START);
		//mouseLog.startCalcDistance();
	}
	
	public ExperimentLogger getExperimentLogger()
	{
		return expLogger;
	}
	
	public void incrementScore()
	{
		score++;
	}
	
	/**
	 * Used to perform actions on each clock tick
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		
		// show the score and the timer
		view.setStatusCell(score, ticks);
		
		// when my tick is at 0, start the game
		if(ticks==0)
		{
			logger.info("Starting Experiment");
			startGame();
		} else if(ticks < 0)
		{
			// we're counting down. tick count is in negative, show the positive version of it. 
			view.setStatusCell(-1 * ticks);
		} else
		{
			// in the regular game, just show the tick and the 
			view.setStatusCell(score, ticks);
		}
		
		// increment the tickcount at every clock tick
		ticks++;
	}
	
	

	@Override
	public boolean dispatchKeyEvent(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_ESCAPE)
		{
			 if (e.getID() == KeyEvent.KEY_RELEASED){
				 exit();
			 }
		}
		return false;
	}
	@Override
	public void mouseDragged(MouseEvent e) {
	}
	@Override
	public void mouseMoved(MouseEvent e) {
	}

	/** getters that the views will need **/
	public int getRowCount() {
		return ROWS;
	}
	
	public int getColCount() {
		return COLS;
	}

	public int getStatuscellRow() {
		return STATUSCELL_ROW;
	}
	
	public int getStatuscellCol() {
		return STATUSCELL_COL;
	}
}

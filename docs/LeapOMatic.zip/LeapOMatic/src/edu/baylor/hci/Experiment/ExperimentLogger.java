package edu.baylor.hci.Experiment;

import java.awt.Point;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.apache.log4j.Logger;

import edu.baylor.hci.Calibration.MouseLogger;
import edu.baylor.hci.LeapOMatic.PositionLog;
import edu.baylor.hci.LeapOMatic.Settings;
import edu.baylor.hci.LeapOMatic.PositionLog.LogStatus;

public class ExperimentLogger {
	private Long startTime= null;
	private Long endTime=null;
	/** Vars used in drag and drop experiment **/
	private ArrayList<Integer> dragTruePosX = new ArrayList<Integer>();
	private ArrayList<Integer> dragTruePosY = new ArrayList<Integer>();
	private ArrayList<Integer> dropTruePosX = new ArrayList<Integer>();
	private ArrayList<Integer> dropTruePosY = new ArrayList<Integer>();
	private ArrayList<Integer> dndTruePosTime = new ArrayList<Integer>(); // duration, not timestamp
	private ArrayList<Integer> dndTruePosDistance = new ArrayList<Integer>();
	private ArrayList<Integer> dragHoverTime = new ArrayList<Integer>();
	
	private ArrayList<Integer> dragFalsePosX = new ArrayList<Integer>();
	private ArrayList<Integer> dragFalsePosY = new ArrayList<Integer>();
	private ArrayList<Integer> dropFalsePosX = new ArrayList<Integer>();
	private ArrayList<Integer> dropFalsePosY = new ArrayList<Integer>();
	private ArrayList<Integer> dndFalsePosTime = new ArrayList<Integer>(); // duration, not timestamp
	private ArrayList<Integer> dndFalsePosDistance = new ArrayList<Integer>();
	
	/** vars used in the Click experiment **/
	private ArrayList<Integer> truePosX = new ArrayList<Integer>();
	private ArrayList<Integer> truePosY = new ArrayList<Integer>();
	private ArrayList<Long> truePosTime = new ArrayList<Long>();
	
	private ArrayList<Integer> falsePosX= new ArrayList<Integer>();
	private ArrayList<Integer> falsePosY= new ArrayList<Integer>();
	private ArrayList<Long> falsePosTime= new ArrayList<Long>();
	
	private ArrayList<Long> hoverTime= new ArrayList<Long>();
	
	private ArrayList<Integer> distanceMoved= new ArrayList<Integer>();
	private ArrayList<Long> timeBetweenPositiveClicks= new ArrayList<Long>();
	
	// Comments can be useful
	private ArrayList<String> comments = new ArrayList<String>();
	
	
	
	final static Logger logger = Logger.getLogger(MouseLogger.class); // FIXME: is this used? If yes, this is not the right name
	
	private PositionLog.LogStatus logStatus=LogStatus.IDLE; 
	
	private BufferedWriter outfile;
	private String logfile;
	
	public ExperimentLogger(String logfilePrefix) {	
			// if the directory does not exist, create it or die trying. 
			File dir = new File(Settings.LOGFILE_DIR); 
			if (!dir.exists()) {
				logger.debug("creating directory: " + dir);
				if(dir.mkdir()) {    
					logger.debug("dir created");  
				} else {
					logger.fatal("Could not create directory");
					System.exit(1);
				}
			} else {
				logger.debug("Dir exists");
			}
			
			Date dateNow = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat(Settings.DATE_FORMAT);
	        StringBuilder strDatenow = new StringBuilder(dateFormat.format(dateNow));
	        
			this.logfile = dir + File.separator + logfilePrefix + "_" + strDatenow + ".m";
	}
	
	private void write(String value) {

		try {
			this.outfile.append(value);
		} catch (IOException e) {
			logger.fatal(e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	public void writeComments()
	{
		for(String comment :comments){
			write("%"+comment +"\n");
		}
		
		try {
			this.outfile.flush();
		} catch (IOException e) {
			logger.fatal(e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	private void writeIntegerVars(String varname, ArrayList<Integer> arraylist) {
		// write this one var
		write(varname + " = [");
		
		Iterator<Integer> iterator = arraylist.iterator();
		while(iterator.hasNext()) {
			write(iterator.next().toString());
			if(iterator.hasNext()) {
				write(",");
			}
		}
		write("]");
		write("\n");
		// flush per var
		try {
			this.outfile.flush();
		} catch (IOException e) {
			logger.fatal(e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	private void writeLongVars(String varname, ArrayList<Long> arraylist) {
		// write this one var
		write(varname + " = [");
		
		Iterator<Long> iterator = arraylist.iterator();
		while(iterator.hasNext()) {
			write(iterator.next().toString());
			if(iterator.hasNext()) {
				write(",");
			}
		}
		write("]");
		write("\n");
		// flush per var
		try {
			this.outfile.flush();
		} catch (IOException e) {
			logger.fatal(e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
	}

	
	/**
	 * Frontend to the log writing function. 
	 * Initializes, writes, closes file
	 */
	public void writeLog() {
		logStatus=LogStatus.IDLE;
		/*
		 * FIXME consolidate this with the DND game's start and sizes.
		 */
		if(startTime!=null && endTime!=null) //only will add these comments if startTime and endTime have been set or only in sequentialClicks as we have it outlined now. 
		{
			this.addComment("GameTime : "+(endTime-startTime));
			this.addComment("#falsePos : "+falsePosTime.size());
			this.addComment("#truePos : "+truePosTime.size());
		}
		// init the output file
		FileWriter fstream = null;
		try {
			fstream = new FileWriter(this.logfile);
		} catch (IOException e) {
			e.printStackTrace();
			logger.fatal(e.getMessage());
			System.exit(1);
		}
		this.outfile = new BufferedWriter(fstream);
		this.writeComments();
		// write my vars
	
		this.writeIntegerVars("truePosX", truePosX);
		this.writeIntegerVars("truePosY", truePosY);
		this.writeLongVars("truePosTime", truePosTime);
		
		this.writeIntegerVars("falsePosX", falsePosX);
		this.writeIntegerVars("falsePosY", falsePosY);
		this.writeLongVars("falsePosTime", falsePosTime);
		
		this.writeLongVars("hoverTime", hoverTime);
		
		this.writeIntegerVars("distanceMoved", distanceMoved);
		this.writeLongVars("timeBetweenPositiveClicks", timeBetweenPositiveClicks);
		
		// == write arrays for DnD ==
		this.writeIntegerVars("dragTruePosX", dragTruePosX);
		this.writeIntegerVars("dragTruePosY", dragTruePosY);
		this.writeIntegerVars("dropTruePosX", dropTruePosX);
		this.writeIntegerVars("dropTruePosY", dropTruePosY);
		this.writeIntegerVars("dndTruePosTime", dndTruePosTime);
		this.writeIntegerVars("dndTruePosDistance", dndTruePosDistance);
		
		this.writeIntegerVars("dragFalsePosX", dragFalsePosX);
		this.writeIntegerVars("dragFalsePosY", dragFalsePosY);
		this.writeIntegerVars("dropFalsePosX", dropFalsePosX);
		this.writeIntegerVars("dropFalsePosY", dropFalsePosY);
		this.writeIntegerVars("dndFalsePosTime", dndFalsePosTime);
		this.writeIntegerVars("dndFalsePosDistance", dndFalsePosDistance);
		
		this.writeIntegerVars("dragHoverTime", dragHoverTime);
		
		// close outfile
		try {
			this.outfile.close();
		} catch (IOException e) {
			e.printStackTrace();
			logger.fatal(e.getMessage());
			System.exit(1);
			
		}
		// clear arrays
		clearArrays();
	}
	/*
	 *  sets experiment StartTime
	 */
	public void setStartTime(Long start)
	{
		startTime=start;
	}
	
	/*
	 * sets the experiment endTime
	 */
	public void setEndTime(Long end)
	{
		endTime=end;
	}
	/*
	 * adds a comment to the arrayList of comments, which will be writen later;
	 */
	public void addComment(String comment)
	{
		comments.add(comment);
	}
	/*
	 * Clears all arrays used in the click experiment, called once we have flushed the log.
	 */
	public void clearArrays()
	{
		truePosX.clear();
		truePosY.clear();
		truePosTime.clear();
		
		falsePosX.clear();
		falsePosY.clear();
		falsePosTime.clear();
		
		hoverTime.clear();
		
		distanceMoved.clear();
		timeBetweenPositiveClicks.clear();
	}

	public LogStatus getLogStatus() {
		return logStatus;
	}

	public void setLogStatus(LogStatus logStatus) {
		this.logStatus = logStatus;
	}
	/**
	 *  adds x and y to our arrayLists for storage, also implicitly calls addTimeBetweenPositiveClicks and distanceMoved 
	 * 	to calculate these values and add them to their respective arrayLists.
	 * @param x
	 * @param y
	 */
	public void addTruePosXY(int x, int  y)
	{
		if(logStatus==LogStatus.START)
		{
			truePosX.add(x);
			truePosY.add(y);
			truePosTime.add(System.currentTimeMillis());
			if(truePosTime.size()<=1) // FIXME: whats this for?
			{
				addTimeBetweenPositiveClicks(0L, 0L);
				distanceMoved.add(0);
			}
			else
			{
				addTimeBetweenPositiveClicks(truePosTime.get(truePosTime.size()-2), truePosTime.get(truePosTime.size()-1));
				addDistanceMoved(truePosX.get(truePosX.size()-2), truePosY.get(truePosY.size()-2),x, y); // pass in last click position and current
			}
			
		}
	}
	/**
	 * adds x and y to our falsePos arrayLists, implicitly adds a time stamp to arrayList<Long> falsePosTime.
	 * @param x
	 * @param y
	 */
	public void addFalsePosXY(int x, int  y)
	{
		if(logStatus==LogStatus.START)
		{
			falsePosX.add(x);
			falsePosY.add(y);
			falsePosTime.add(System.currentTimeMillis());
		}
	}
	
	/**
	 * This function is called from addTruePosXY, simply calculates the time from the last positive click until the current, and stores in timeBtweenPositiveClicks.
	 * @param lastPositiveClickTime
	 * @param currentPositiveClickTime
	 */
	private void addTimeBetweenPositiveClicks(Long lastPositiveClickTime, Long currentPositiveClickTime )
	{
		if(logStatus==LogStatus.START)
		{
			timeBetweenPositiveClicks.add(currentPositiveClickTime-lastPositiveClickTime);
		}
	}
	/**
	 * This is called by from outside the class and given the mouseEntered time and the click time calculates and stores the hoverTime.
	 * @param mouseEntered
	 * @param clickTime
	 */
	public void addHoverTime(Long mouseEntered, Long clickTime)
	{
		if(logStatus==LogStatus.START)
		{
			hoverTime.add(clickTime-mouseEntered);
		}
	}
	/**
	 * This function calculates the distance between two points
	 * @param firstPointX
	 * @param firstPointY
	 * @param secondPointX
	 * @param secondPointY
	 */
	private void addDistanceMoved(int firstPointX, int firstPointY, int secondPointX, int secondPointY) //problem is that the position is relative to the button
	{ //absolute value of the distance formula=> positive distance moved
		if(logStatus==LogStatus.START)
		{
			distanceMoved.add(getDistance(firstPointX, firstPointY, secondPointX, secondPointY));
		}
	}
	
	/**
	 * Adds the Drag coords and Drop coords in pixels, where this is a True Positive
	 * Also implicitly sets the TP time and relevant distance
	 * @param drag - XY point where the drag started. In absolute screen pixel
	 * @param drop - XY point where the drop occured. In absolute screen pixel
	 * @param startTime - time in milliseconds when the drag started.
	 * @param stopTime - time in milliseconds when the drop finished
	 */
	public void addDndTruePos(Point drag, Point drop, Long startTime, Long stopTime) {
		if(logStatus==LogStatus.START)
		{
			// straightforward - set the values. 
			this.dragTruePosX.add(drag.x);
			this.dragTruePosY.add(drag.y);
			this.dropTruePosX.add(drop.x);
			this.dropTruePosY.add(drop.y);
			// this logs the time between the drag and the drop.. 
			this.dndTruePosTime.add((int)(stopTime - startTime));
			// use the distance formula, add the distance between the drag and the drop. 
			this.dndTruePosDistance.add(this.getDistance(drag.x, drag.y, drop.x, drop.y));
		}
	}
	
	/**
	 * Adds the Drag coords and Drop coords in pixels, where this is a False Positive
	 * Also implicitly sets the FP time
	 * @param drag - XY point where the drag started. In absolute screen pixel
	 * @param drop - XY point where the drop occured. In absolute screen pixel
	 * @param startTime - time in milliseconds when the drag started.
	 * @param stopTime - time in milliseconds when the drop finished
	 */
	public void addDndFalsePos(Point drag, Point drop, Long startTime, Long stopTime) {
		if(logStatus==LogStatus.START)
		{
			/// add coord values
			this.dragFalsePosX.add(drag.x);
			this.dragFalsePosY.add(drag.y);
			this.dropFalsePosX.add(drop.x);
			this.dropFalsePosY.add(drop.y);
			// distance between startTime and end time. 
			// NOTE: theoretically could be 0 (or very close to 0) if this is a Click. but the dnd system shouldn't care about the clicks. so. 
			this.dndFalsePosTime.add((int)(stopTime - startTime));
			// use the distance formula, add the distance between the drag and the drop.
			/* NOTE: why do we need the distance for a false positive? No idea. 
			 *     But the difference between a long distance FP and a short distance FP may indicate the difference between system 
			 *     related issue (eg: accidentally detecting grab / grasp / pinch actions) and user related issue 
			 *     (eg: missed the drop point)
			 */
			this.dndFalsePosDistance.add(this.getDistance(drag.x, drag.y, drop.x, drop.y));
		}
	}

	/**
	 * How long did the user pause over the widget before selecting it. 
	 * This should include re-entries, so don't restart the clock when reentries occur. 
	 * @param hovertime
	 */
	public void addDragHoverTime(int hovertime) {
		if(logStatus==LogStatus.START)
		{
			this.dragHoverTime.add(hovertime);
		}
	}
	
	/**
	 * Returns the Eucledian distance between 2 points. 
	 * Uses integers because of the context: we measure in Pixels, floating precision is pointless
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 * @return Eucledian Distance 
	 */
	private int getDistance(int x1, int y1, int x2, int y2) {
		int xDist = x1 - x2;
		int yDist = y1 - y2; 
		return (int) Math.sqrt(xDist * xDist + yDist * yDist);	
	}

}

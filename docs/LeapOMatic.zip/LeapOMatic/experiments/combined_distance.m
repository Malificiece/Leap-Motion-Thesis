% total 
nankai_mouse = 88609;
nankai_leap = 152376;
nankai_lom = 98895;

garrett_mouse = 98064;
garrett_leap = 102659;
garrett_lom = 101251;

qiaoli_mouse = 131686;
qiaoli_leap = 120647;
qiaoli_lom = 135931;

yanan_mouse = 73613;
yanan_leap = 112628;
yanan_lom = 114653;

roman_mouse = 90135;
roman_leap = 107480; 
roman_lom = 108286;

%% REMOVE THIS LATER
alvin_mouse = 82891;
alvin_leap = 91714;
alvin_lom = 90175;

darren_mouse = 84254;
darren_leap = 93105;
darren_lom = 86946;

%% == EVERYONE
combined_mouse = [darren_mouse; alvin_mouse; yanan_mouse; nankai_mouse; garrett_mouse; qiaoli_mouse];
combined_leap = [darren_leap; alvin_leap; yanan_leap; nankai_leap; garrett_leap; qiaoli_leap];
combined_lom = [darren_lom; alvin_lom; yanan_lom; nankai_lom; garrett_lom; qiaoli_lom];

%% == EXCLUDES Alvin, Darren,
combined_mouse = [yanan_mouse; nankai_mouse; garrett_mouse; qiaoli_mouse; roman_mouse];
combined_leap = [yanan_leap; nankai_leap; garrett_leap; qiaoli_leap; roman_leap];
combined_lom = [yanan_lom; nankai_lom; garrett_lom; qiaoli_lom; roman_lom];

%% == EXCLUDES QiaoLi
%combined_mouse = [darren_mouse; alvin_mouse; yanan_mouse; nankai_mouse; garrett_mouse; roman_mouse];
%combined_leap = [darren_leap; alvin_leap; yanan_leap; nankai_leap; garrett_leap; roman_leap];
%combined_lom = [darren_lom; alvin_lom; yanan_lom; nankai_lom; garrett_lom; roman_lom];

combined_dist= [combined_mouse, combined_leap, combined_lom];

%% sets size of image
hFig = figure(1);
set(hFig, 'Position', [1 1 600 700])
h = boxplot(combined_dist, 'labels', {'Mouse', 'De facto', 'Personal Space'})
set(gca, 'FontSize', 14) % affects title and Ylabel
set(findobj(gca,'Type','text'),'FontSize',15)
ylabel('Pixels');
title('Pilot 2 - Total Distance Travelled')
% do anova for all
[p, table, stats] = anova1([combined_mouse, combined_leap, combined_lom])
% and ttest for just the gestures
% [h, p, ci, stats] = ttest2(combined_hover_leap, combined_hover_lom)
[h, p] = ttest2(combined_leap, combined_lom)

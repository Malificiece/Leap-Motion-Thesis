% times for Each persons Hover in seconds

qiaoli_hover_mouse = 121;
qiaoli_hover_leap = 179;
qiaoli_hover_lom = 248;

garrett_hover_mouse = 103;
garrett_hover_leap = 151;
garrett_hover_lom = 148;

nankai_hover_mouse = 108;
nankai_hover_leap = 186;
nankai_hover_lom = 157;

yanan_hover_mouse = 104;
yanan_hover_leap= 174;
yanan_hover_lom = 219;

roman_hover_mouse = 112;
roman_hover_leap= 153;
roman_hover_lom = 243;


combined_hover_mouse = [qiaoli_hover_mouse; garrett_hover_mouse; nankai_hover_mouse; yanan_hover_mouse; roman_hover_mouse];
combined_hover_leap = [qiaoli_hover_leap; garrett_hover_leap; nankai_hover_leap; yanan_hover_leap; roman_hover_leap];
combined_hover_lom = [qiaoli_hover_lom; garrett_hover_lom; nankai_hover_lom; yanan_hover_lom; roman_hover_lom];

combined_hov = [combined_hover_mouse, combined_hover_leap, combined_hover_lom];
set(gca, 'FontSize', 14) % affects title and Ylabel
 hFig = figure(1);
  set(hFig, 'Position', [100 100 600 700])
h = boxplot(combined_hov,  'Labels', {'Mouse', 'De facto', 'Personal Space'})
set(findobj(get(h(1), 'parent'), 'type', 'text'), 'fontsize', 16);
ylabel('Seconds');
title('Pilot 2 - Completion Time')

% do anova for all
[p, table, stats] = anova1([combined_hover_mouse, combined_hover_leap, combined_hover_lom])
% and ttest for just the gestures
% [h, p, ci, stats] = ttest2(combined_hover_leap, combined_hover_lom)
[h, p] = ttest2(combined_hover_leap, combined_hover_lom)

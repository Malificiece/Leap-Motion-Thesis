function regression_linear_robust_path(mouseFile, leapFile, lomFile) 

hold off
hold on

func = 'bisquare'

feval(str2func(mouseFile));
travelTime = distanceMovedEnd - distanceMovedStart
fitted = robustfit(distanceMoved,travelTime, func);
plot(distanceMoved, travelTime, 'bo');
plot(distanceMoved, fitted(1) + fitted(2) * distanceMoved, 'b-');


feval(str2func(leapFile))
travelTime = distanceMovedEnd - distanceMovedStart
fitted = robustfit(distanceMoved,travelTime, func);
plot(distanceMoved, travelTime, 'g+');
plot(distanceMoved, fitted(1) + fitted(2) * distanceMoved, 'g-');


feval(str2func(lomFile))
travelTime = distanceMovedEnd - distanceMovedStart
fitted = robustfit(distanceMoved,travelTime, func);
plot(distanceMoved, travelTime, 'r^');
plot(distanceMoved, fitted(1) + fitted(2) * distanceMoved, 'r-');

ylabel('Time (ms)');
xlabel('Distance (pixels)');

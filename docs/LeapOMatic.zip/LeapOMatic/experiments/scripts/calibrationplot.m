hold on;
scatter3(topRightClusterZ, topRightClusterX, topRightClusterY, 'bo');
scatter3(botRightClusterZ, botRightClusterX, botRightClusterY, 'bo');
scatter3(topLeftClusterZ, topLeftClusterX, topLeftClusterY, 'bo');
scatter3(botLeftClusterZ, botLeftClusterX, botLeftClusterY, 'bo');

scatter3(topRightCollectedZ, topRightCollectedX, topRightCollectedY, 'r.');
scatter3(botRightCollectedZ, botRightCollectedX, botRightCollectedY, 'r.');
scatter3(topLeftCollectedZ, topLeftCollectedX, topLeftCollectedY, 'r.');
scatter3(botLeftCollectedZ, botLeftCollectedX, botLeftCollectedY, 'r.');
hold off;

grid on;
xlabel('Z')
ylabel('X')
zlabel('Y')

function regression_linear_polyfit(mouseFile, leapFile, lomFile) 

hold off
hold on

feval(str2func(mouseFile));
linearCoef = polyfit(distanceMoved,timeBetweenPositiveClicks,1);
linearFit = polyval(linearCoef, distanceMoved);
plot(distanceMoved, timeBetweenPositiveClicks, 'bo', distanceMoved, linearFit, 'b-', [0,3000],[0,0], 'k:', [0,3000], [1,1], 'k:')

feval(str2func(leapFile))
linearCoef = polyfit(distanceMoved,timeBetweenPositiveClicks,1);
linearFit = polyval(linearCoef, distanceMoved);
plot(distanceMoved, timeBetweenPositiveClicks, 'g+', distanceMoved, linearFit, 'g-', [0,3000],[0,0], 'k:', [0,3000], [1,1], 'k:')

feval(str2func(lomFile))
linearCoef = polyfit(distanceMoved,timeBetweenPositiveClicks,1);
linearFit = polyval(linearCoef, distanceMoved);
plot(distanceMoved, timeBetweenPositiveClicks, 'r^', distanceMoved, linearFit, 'r-', [0,3000],[0,0], 'k:', [0,3000], [1,1], 'k:')

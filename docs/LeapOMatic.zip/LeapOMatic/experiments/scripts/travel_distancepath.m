function travel_distancepath(expMouseFile, expleapFile, expLomFile, mouseMouseFile, mouseleapFile, mouseLomFile) 

hold off
hold on

%robust regression model
func = 'bisquare'

feval(str2func(expMouseFile));
eucDistance = distanceMoved;
feval(str2func(mouseMouseFile));
distanceDifference = distanceMoved - eucDistance
plot(eucDistance, distanceDifference, 'bo');
%fit a graph here. 
fitted = robustfit(eucDistance, distanceDifference, func);
plot(eucDistance, fitted(1) + fitted(2) * eucDistance, 'b-');


feval(str2func(expleapFile));
eucDistance = distanceMoved;
feval(str2func(mouseleapFile));
distanceDifference = distanceMoved - eucDistance
plot(eucDistance, distanceDifference, 'g+');
fitted = robustfit(eucDistance, distanceDifference, func);
plot(eucDistance, fitted(1) + fitted(2) * eucDistance, 'g-');


feval(str2func(expLomFile));
eucDistance = distanceMoved;
feval(str2func(mouseLomFile));
distanceDifference = distanceMoved - eucDistance
plot(eucDistance, distanceDifference, 'r^');
fitted = robustfit(eucDistance, distanceDifference, func);
plot(eucDistance, fitted(1) + fitted(2) * eucDistance, 'r-');

%just a NORMAl line on the 0
plot([0, 3500], [0, 0], 'k--');

ylabel('Travelled Distance');
xlabel('Actual Distance');

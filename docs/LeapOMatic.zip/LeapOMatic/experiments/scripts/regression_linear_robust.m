function regression_linear_robust(mouseFile, leapFile, lomFile) 

hold off
hold on

% DEFAULT = 'bisquare'
func = 'bisquare'

feval(str2func(mouseFile));
fitted = robustfit(distanceMoved,timeBetweenPositiveClicks, func);
plot(distanceMoved, timeBetweenPositiveClicks, 'bo');
plot(distanceMoved, fitted(1) + fitted(2) * distanceMoved, 'b-');


feval(str2func(leapFile))
fitted = robustfit(distanceMoved,timeBetweenPositiveClicks, func);
plot(distanceMoved, timeBetweenPositiveClicks, 'g+');
plot(distanceMoved, fitted(1) + fitted(2) * distanceMoved, 'g-');


feval(str2func(lomFile))
fitted = robustfit(distanceMoved,timeBetweenPositiveClicks, func);
plot(distanceMoved, timeBetweenPositiveClicks, 'r^');
plot(distanceMoved, fitted(1) + fitted(2) * distanceMoved, 'r-');

ylabel('Time (ms)');
xlabel('Distance (pixels)');

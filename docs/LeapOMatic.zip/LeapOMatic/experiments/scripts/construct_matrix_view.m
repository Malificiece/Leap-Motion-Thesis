function construct_matrix_view(calibrationLog, positionLog)

hold off
hold on

feval(str2func(positionLog));
%scatter3(SZ, SX, SY);

feval(str2func(calibrationLog));

XPoints = [topRightPointZ, topLeftPointZ, botLeftPointZ, botRightPointZ]

YPoints = [topRightPointX, topLeftPointX, botLeftPointX, botRightPointX]

ZPoints =  [topRightPointY, topLeftPointY, botLeftPointY, botRightPointY]



planeFill2=fill3(XPoints, YPoints, ZPoints, 'k', 'FaceAlpha', 0.1)

hold on

%curveFill = fill3(SZ, SX, SY, SX, 'FaceAlpha', 0.2)

% view([-100, 30]); %front view
view([-134, 6]); % side view
grid on


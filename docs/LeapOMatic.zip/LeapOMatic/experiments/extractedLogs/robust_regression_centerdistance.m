function robust_regression_centerDistance(mouseFile, leapFile, lomFile)

hold off
hold on

% DEFAULT = 'bisquare'
func = 'bisquare'

feval(str2func(mouseFile));
fitted = robustfit(distanceFromCenter,timeBetweenPositiveClicks, func);
plot(distanceFromCenter, timeBetweenPositiveClicks, 'bo');
plot(distanceFromCenter, fitted(1) + fitted(2) * distanceFromCenter, 'b-');


feval(str2func(leapFile))
fitted = robustfit(distanceFromCenter,timeBetweenPositiveClicks, func);
plot(distanceFromCenter, timeBetweenPositiveClicks, 'g+');
plot(distanceFromCenter, fitted(1) + fitted(2) * distanceFromCenter, 'g-');


feval(str2func(lomFile))
fitted = robustfit(distanceFromCenter,timeBetweenPositiveClicks, func);
plot(distanceFromCenter, timeBetweenPositiveClicks, 'r^');
plot(distanceFromCenter, fitted(1) + fitted(2) * distanceFromCenter, 'r-');

ylabel('Time (ms)');
xlabel('Distance (pixels)');

% times for Each persons Hover in seconds

ed_hover_mouse = 105;
ed_hover_leap = 132;
ed_hover_lom = 129;

christian_hover_mouse = 102;
christian_hover_leap = 140;
christian_hover_lom = 129;

ryanyan_hover_mouse = 104;
ryanyan_hover_leap = 155;
ryanyan_hover_lom = 178;

lizhu_hover_mouse = 102;
lizhu_hover_leap = 146;
lizhu_hover_lom = 207;

ryanh_hover_mouse = 105;
ryanh_hover_leap = 155;
ryanh_hover_lom = 140;

rovshen_hover_mouse = 104;
rovshen_hover_leap = 143;
rovshen_hover_lom = 166;

laura_hover_mouse = 105;
laura_hover_leap = 183;
laura_hover_lom = 182;

combined_hover_mouse = [ed_hover_mouse; christian_hover_mouse; ryanyan_hover_mouse; lizhu_hover_mouse; ryanh_hover_mouse; rovshen_hover_mouse; laura_hover_mouse];
combined_hover_leap = [ed_hover_leap; christian_hover_leap; ryanyan_hover_leap; lizhu_hover_leap; ryanh_hover_leap; rovshen_hover_leap; laura_hover_leap];
combined_hover_lom = [ed_hover_lom; christian_hover_lom; ryanyan_hover_lom; lizhu_hover_lom; ryanh_hover_lom; rovshen_hover_lom; laura_hover_lom];

combined_hov = [combined_hover_mouse, combined_hover_leap, combined_hover_lom];
set(gca, 'FontSize', 14) % affects title and Ylabel
 hFig = figure(1);
 set(hFig, 'Position', [100 100 600 700])
h = boxplot(combined_hov,  'Labels', {'Mouse', 'De facto', 'Personal Space'})
set(findobj(get(h(1), 'parent'), 'type', 'text'), 'fontsize', 16);
ylabel('Seconds');
title('Pilot 1 - Completion Time')

% do anova for all
[p, table, stats] = anova1([combined_hover_mouse, combined_hover_leap, combined_hover_lom])
% and ttest for just the gestures
% [h, p, ci, stats] = ttest2(combined_hover_leap, combined_hover_lom)
[h, p] = ttest2(combined_hover_leap, combined_hover_lom)
